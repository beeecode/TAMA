import { useState } from 'react';
import React from 'react';
import { Sidebar } from './components/Sidebar';
import { SparkleIcon, Button } from './components/ui';

import Landing from './screens/Landing';
import SignUp from './screens/SignUp';
import Home from './screens/Home';
import Tasks from './screens/Tasks';
import Board from './screens/Board';
import Timeline from './screens/Timeline';
import ForecastDetail from './screens/ForecastDetail';
import TaskDetail from './screens/TaskDetail';
import Team from './screens/Team';
import Automations from './screens/Automations';
import Reporting from './screens/Reporting';
import AskTAMA from './screens/AskTAMA';
import Settings from './screens/Settings';
import Inbox from './screens/Inbox';

type Screen =
  | 'landing' | 'signup' | 'signin' | 'onboarding'
  | 'home' | 'tasks' | 'board' | 'timeline'
  | 'forecast' | 'inbox' | 'calendar' | 'team'
  | 'docs' | 'automations' | 'reporting' | 'settings';

// Simple docs placeholder
function DocsScreen() {
  return (
    <div>
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="text-text-tertiary mb-1" style={{ fontSize: 12 }}>Workspace</div>
          <h1 style={{ fontSize: 34, fontWeight: 600, fontFamily: 'var(--font-tight)', letterSpacing: '-0.005em', margin: 0, color: '#171614' }}>Docs</h1>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2" width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="6" cy="6" r="4" /><path d="M9 9l3 3" />
            </svg>
            <input className="rounded-lg pl-9 pr-3" style={{ width: 220, height: 36, border: '1px solid #D6D3CC', background: '#FFFFFF', fontSize: 13, outline: 'none' }} placeholder="Search docs..." />
          </div>
          <Button variant="primary" size="sm">New doc</Button>
        </div>
      </div>
      <div className="grid gap-5" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
        {[
          { title: 'Q3 Campaign Strategy', excerpt: 'This document outlines the strategic direction for our Q3 summer campaign, including messaging hierarchy and channel strategy...', edited: '2h ago', ai: true },
          { title: 'Orion API Gateway Spec', excerpt: 'Technical specification for the Orion API Gateway project. Includes auth requirements, rate limiting approach, and endpoint definitions...', edited: '1d ago', ai: false },
          { title: 'Vega Brand Guidelines', excerpt: 'Brand guidelines for the Vega Brand Refresh project. Color tokens, typography scales, and usage rules...', edited: '3d ago', ai: true },
          { title: 'Q1 Retrospective', excerpt: 'Key outcomes and learnings from Q1 2026. Delivered 3 of 5 major initiatives on time. Two projects slipped by an average of 6 days...', edited: '1w ago', ai: false },
          { title: 'Team Onboarding Guide', excerpt: 'Getting started with TAMA for new team members. Setting up integrations, understanding your first forecast...', edited: '2w ago', ai: false },
          { title: 'Atlas CRM Migration Plan', excerpt: 'Runbook for migrating the contact database to the new Atlas CRM schema. Includes rollback procedures and data validation steps...', edited: '3d ago', ai: true },
        ].map((doc, i) => (
          <div
            key={i}
            className="rounded-xl p-5 hover:shadow-el2 transition-shadow cursor-pointer"
            style={{
              background: '#FFFFFF',
              border: '1px solid #E8E6E1',
              boxShadow: '0 1px 2px rgba(23,22,20,0.04)',
            }}
          >
            <div className="flex items-start gap-3 mb-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
                <path d="M6 2h9l5 5v15a1 1 0 01-1 1H6a1 1 0 01-1-1V3a1 1 0 011-1z" />
                <path d="M15 2v5h5M9 12h6M9 16h4" />
              </svg>
              <div className="flex-1 min-w-0">
                <h3 className="text-text-primary font-semibold truncate" style={{ fontSize: 14, fontFamily: 'var(--font-tight)' }}>{doc.title}</h3>
              </div>
              {doc.ai && (
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full flex-shrink-0" style={{ background: '#EEEFFC', fontSize: 10, color: '#5F63C9', fontWeight: 500 }}>
                  <SparkleIcon size={10} />
                  Auto-synced
                </span>
              )}
            </div>
            <p className="text-text-secondary mb-4" style={{ fontSize: 12, lineHeight: '18px', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
              {doc.excerpt}
            </p>
            <div className="flex items-center justify-between">
              <div className="flex -space-x-1.5">
                {[{ i: 'CW', c: '#F2622E' }, { i: 'AM', c: '#EC4899' }].slice(0, i % 2 === 0 ? 2 : 1).map((a, j) => (
                  <div key={j} className="flex items-center justify-center rounded-full text-white" style={{ width: 20, height: 20, background: a.c, fontSize: 8, fontWeight: 600, border: '2px solid white' }}>{a.i}</div>
                ))}
              </div>
              <span className="text-text-tertiary" style={{ fontSize: 11 }}>Edited {doc.edited}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Onboarding screen
function OnboardingScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [step, setStep] = useState(2);

  const INTEGRATIONS = [
    { name: 'Google Calendar', cat: 'Calendar', connected: true, icon: '📅' },
    { name: 'Slack', cat: 'Messaging', connected: true, icon: '💬' },
    { name: 'Google Drive', cat: 'Storage', connected: false, icon: '📂' },
    { name: 'Notion', cat: 'Docs', connected: false, icon: '📝' },
    { name: 'Gmail', cat: 'Email', connected: false, icon: '📧' },
    { name: 'Asana', cat: 'Tasks', connected: false, icon: '✅' },
    { name: 'Jira', cat: 'Tasks', connected: false, icon: '🔷' },
    { name: 'Figma', cat: 'Design', connected: false, icon: '🎨' },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center pt-16 px-6" style={{ background: '#FAFAF8' }}>
      {/* Logo */}
      <div className="flex items-center gap-2 mb-12">
        <div className="flex items-center justify-center rounded-lg text-white font-bold" style={{ width: 28, height: 28, background: '#5F63C9', fontFamily: 'var(--font-tight)', fontSize: 14 }}>T</div>
        <span style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 20, letterSpacing: '-0.02em', color: '#171614' }}>TAMA</span>
      </div>

      {/* Progress */}
      <div className="flex items-center gap-2 mb-10">
        {[1, 2, 3, 4].map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div
              className="rounded-full"
              style={{
                width: s < step ? 12 : s === step ? 16 : 10,
                height: s < step ? 12 : s === step ? 16 : 10,
                background: s < step ? '#5F63C9' : s === step ? '#5F63C9' : '#D6D3CC',
                boxShadow: s === step ? '0 0 0 4px rgba(95,99,201,0.15)' : 'none',
                transition: 'all 0.18s',
              }}
            />
            {i < 3 && <div className="h-px w-8" style={{ background: s < step ? '#5F63C9' : '#D6D3CC' }} />}
          </div>
        ))}
      </div>
      <p className="text-text-tertiary mb-8 uppercase" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>Step {step} of 4</p>

      <div style={{ width: '100%', maxWidth: 640 }}>
        <h1 style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 28, letterSpacing: '-0.005em', margin: '0 0 8px', color: '#171614', textAlign: 'center' }}>
          Connect where work already happens
        </h1>
        <p className="text-text-secondary text-center mb-8" style={{ fontSize: 14 }}>
          TAMA needs two sources to build your first forecast.
        </p>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {INTEGRATIONS.map(int => (
            <div
              key={int.name}
              className="flex items-center gap-3 rounded-xl px-4 transition-all cursor-pointer"
              style={{
                height: 72,
                background: int.connected ? '#EEEFFC' : '#FFFFFF',
                border: `1px solid ${int.connected ? '#8B8FE8' : '#E8E6E1'}`,
                boxShadow: '0 1px 2px rgba(23,22,20,0.04)',
              }}
            >
              <span style={{ fontSize: 28 }}>{int.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="text-text-primary font-semibold" style={{ fontSize: 13 }}>{int.name}</div>
                <div className="text-text-tertiary" style={{ fontSize: 11 }}>{int.cat}</div>
              </div>
              {int.connected ? (
                <div className="flex items-center justify-center rounded-full" style={{ width: 24, height: 24, background: '#5F63C9' }}>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round">
                    <path d="M2 6l2.5 2.5L10 3" />
                  </svg>
                </div>
              ) : (
                <div className="rounded-full" style={{ width: 24, height: 24, border: '1.5px solid #D6D3CC' }} />
              )}
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#2F9E6B" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="8" cy="8" r="6" /><path d="M5 8l2 2 4-4" />
            </svg>
            <span className="text-text-secondary" style={{ fontSize: 13 }}>2 of 2 minimum connected</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm">Skip for now</Button>
            <Button variant="primary" size="lg" onClick={() => onNavigate('home')}>
              Continue
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('landing');
  const [showTaskDetail, setShowTaskDetail] = useState(false);
  const [showAskTAMA, setShowAskTAMA] = useState(false);

  const navigate = (s: string) => setScreen(s as Screen);

  const isFullPage = ['landing', 'signup', 'signin', 'onboarding'].includes(screen);

  if (screen === 'landing') return <Landing onNavigate={navigate} />;
  if (screen === 'signup') return <SignUp mode="signup" onNavigate={navigate} />;
  if (screen === 'signin') return <SignUp mode="signin" onNavigate={navigate} />;
  if (screen === 'onboarding') return <OnboardingScreen onNavigate={navigate} />;

  const screenMap: Record<string, React.ReactElement> = {
    home: <Home />,
    tasks: <Tasks />,
    board: <Board />,
    timeline: <Timeline />,
    forecast: <ForecastDetail />,
    inbox: <Inbox />,
    team: <Team />,
    docs: <DocsScreen />,
    automations: <Automations />,
    reporting: <Reporting />,
    settings: <Settings />,
    calendar: (
      <div className="flex flex-col items-center justify-center h-full text-center" style={{ minHeight: 400 }}>
        <div style={{ fontSize: 40, marginBottom: 16 }}>📅</div>
        <h2 style={{ fontSize: 22, fontWeight: 600, fontFamily: 'var(--font-tight)', margin: '0 0 8px', color: '#171614' }}>Calendar</h2>
        <p className="text-text-secondary" style={{ fontSize: 14 }}>Calendar view coming soon. Events from Google Calendar are already informing your forecasts.</p>
      </div>
    ),
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#FAFAF8' }}>
      <Sidebar active={screen} onNavigate={navigate} />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <div
          className="flex items-center justify-between px-6 flex-shrink-0"
          style={{ height: 52, borderBottom: '1px solid #E8E6E1', background: '#FFFFFF' }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAskTAMA(true)}
              className="flex items-center gap-2 px-3 rounded-lg transition-colors cursor-pointer hover:bg-surface-hover"
              style={{ height: 36, background: '#EEEFFC', border: '1px solid #DCDDF8', fontSize: 13 }}
            >
              <SparkleIcon size={14} />
              <span className="text-ai-strong">Ask TAMA</span>
              <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: '#8B8FE8', padding: '1px 5px', background: '#DCDDF8', borderRadius: 4 }}>⌘K</span>
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('inbox')}
              className="relative p-2 rounded-lg hover:bg-surface-hover transition-colors cursor-pointer"
              style={{ background: 'none', border: 'none' }}
            >
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="#6B6862" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M1 10h4L7 13h4l2-3h4" /><path d="M1 10V4a1 1 0 011-1h14a1 1 0 011 1v6" />
              </svg>
              <span
                className="absolute -top-0.5 -right-0.5 rounded-full text-white flex items-center justify-center"
                style={{ width: 15, height: 15, background: '#8B8FE8', fontSize: 9, fontWeight: 700, fontFamily: 'var(--font-mono)' }}
              >
                11
              </span>
            </button>
            <div className="flex items-center justify-center rounded-full text-white font-semibold cursor-pointer" style={{ width: 32, height: 32, background: '#F2622E', fontSize: 12, fontFamily: 'var(--font-tight)' }}>
              CW
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-y-auto p-8">
          {screenMap[screen] ?? screenMap['home']}
        </div>
      </div>

      {/* Task detail slide-over */}
      {showTaskDetail && (
        <>
          <div
            className="fixed inset-0 z-40"
            style={{ background: 'rgba(23,22,20,0.2)' }}
            onClick={() => setShowTaskDetail(false)}
          />
          <TaskDetail onClose={() => setShowTaskDetail(false)} />
        </>
      )}

      {/* Ask TAMA overlay */}
      {showAskTAMA && <AskTAMA onClose={() => setShowAskTAMA(false)} />}

      {/* Demo: floating task detail trigger */}
      <button
        onClick={() => setShowTaskDetail(true)}
        className="fixed bottom-6 right-6 flex items-center gap-2 rounded-full shadow-lg cursor-pointer z-30 transition-all hover:scale-105"
        style={{ background: '#F2622E', border: 'none', color: 'white', padding: '10px 18px', fontSize: 13, fontWeight: 500 }}
      >
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round">
          <rect x="1" y="1" width="12" height="12" rx="2" /><path d="M4 5h6M4 7h6M4 9h4" />
        </svg>
        Open task detail
      </button>
    </div>
  );
}
