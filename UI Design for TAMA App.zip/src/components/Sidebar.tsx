import { useState } from 'react';

const NAV_ITEMS = [
  { id: 'home', label: 'Home', icon: HomeIcon },
  { id: 'tasks', label: 'Tasks', icon: TasksIcon },
  { id: 'forecast', label: 'Forecast', icon: ForecastIcon },
  { id: 'inbox', label: 'Inbox', icon: InboxIcon, badge: 11 },
  { id: 'calendar', label: 'Calendar', icon: CalendarIcon },
  { id: 'team', label: 'Team', icon: TeamIcon },
  { id: 'docs', label: 'Docs', icon: DocsIcon },
  { id: 'automations', label: 'Automations', icon: AutomationsIcon },
  { id: 'reporting', label: 'Reporting', icon: ReportingIcon },
];

const PROJECTS = [
  { id: 'atlas', label: 'Atlas CRM Revamp', color: '#22C55E' },
  { id: 'nimbus', label: 'Nimbus Dashboard', color: '#F97316' },
  { id: 'orion', label: 'Orion API Gateway', color: '#3B82F6' },
  { id: 'helio', label: 'Helio Task System', color: '#EC4899' },
  { id: 'vega', label: 'Vega Brand Refresh', color: '#8B5CF6' },
];

interface SidebarProps {
  active: string;
  onNavigate: (id: string) => void;
}

export function Sidebar({ active, onNavigate }: SidebarProps) {
  const [projectsOpen, setProjectsOpen] = useState(true);

  return (
    <div
      className="flex flex-col h-full flex-shrink-0"
      style={{
        width: 264,
        background: '#F5F4F1',
        borderRight: '1px solid #E8E6E1',
      }}
    >
      {/* Workspace switcher */}
      <div className="p-3">
        <div
          className="flex items-center gap-2.5 p-2.5 rounded-xl bg-surface cursor-pointer hover:bg-surface-hover transition-colors"
          style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)' }}
        >
          <div
            className="flex-shrink-0 flex items-center justify-center rounded-lg text-white text-xs font-bold"
            style={{ width: 32, height: 32, background: '#5F63C9', fontFamily: 'var(--font-tight)', fontSize: 13 }}
          >
            T
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-text-primary font-semibold truncate" style={{ fontSize: 13, fontFamily: 'var(--font-tight)' }}>
              Meridian Ops
            </div>
            <div className="text-text-tertiary" style={{ fontSize: 11 }}>Team · 24 members</div>
          </div>
          <ChevronIcon />
        </div>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div
          className="flex items-center gap-2 px-3 rounded-lg bg-surface cursor-text"
          style={{ height: 36, border: '1px solid #E8E6E1', fontSize: 13 }}
        >
          <SearchIcon />
          <span className="text-text-tertiary flex-1">Search</span>
          <span
            className="text-text-tertiary rounded px-1.5 py-0.5 bg-surface-sunk"
            style={{ fontSize: 10, fontFamily: 'var(--font-mono)' }}
          >
            ⌘F
          </span>
        </div>
      </div>

      {/* Essentials */}
      <div className="px-3 pb-1">
        <div
          className="text-text-tertiary mb-1 mt-1"
          style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase' }}
        >
          Essentials
        </div>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="w-full flex items-center gap-2.5 px-2.5 rounded-lg transition-colors mb-0.5 cursor-pointer"
              style={{
                height: 36,
                background: isActive ? '#FFFFFF' : 'transparent',
                boxShadow: isActive ? '0 1px 2px rgba(23,22,20,0.04)' : 'none',
                border: isActive ? '1px solid #E8E6E1' : '1px solid transparent',
              }}
            >
              <Icon active={isActive} />
              <span
                className={isActive ? 'text-text-primary font-medium' : 'text-text-secondary'}
                style={{ fontSize: 13, fontFamily: 'var(--font-sans)' }}
              >
                {item.label}
              </span>
              {item.badge && (
                <span
                  className="ml-auto rounded-full text-white flex items-center justify-center"
                  style={{
                    background: '#8B8FE8',
                    fontSize: 10,
                    fontWeight: 600,
                    minWidth: 18,
                    height: 18,
                    padding: '0 5px',
                    fontFamily: 'var(--font-mono)',
                  }}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Projects */}
      <div className="px-3 mt-2">
        <div className="flex items-center justify-between mb-1">
          <span
            className="text-text-tertiary"
            style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase' }}
          >
            Projects
          </span>
          <div className="flex items-center gap-1">
            <button className="text-text-tertiary hover:text-text-secondary p-0.5 rounded transition-colors cursor-pointer">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <path d="M7 3v8M3 7h8" />
              </svg>
            </button>
            <button
              onClick={() => setProjectsOpen(!projectsOpen)}
              className="text-text-tertiary hover:text-text-secondary p-0.5 rounded transition-colors cursor-pointer"
            >
              <svg
                width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
                style={{ transform: projectsOpen ? 'rotate(0deg)' : 'rotate(-90deg)', transition: 'transform 0.18s' }}
              >
                <path d="M4 6l3 3 3-3" />
              </svg>
            </button>
          </div>
        </div>
        {projectsOpen && PROJECTS.map((p) => (
          <button
            key={p.id}
            onClick={() => onNavigate('forecast')}
            className="w-full flex items-center gap-2 px-2 rounded-lg hover:bg-surface-hover transition-colors mb-0.5 cursor-pointer"
            style={{ height: 32 }}
          >
            <div
              className="flex-shrink-0 rounded"
              style={{ width: 10, height: 10, background: p.color, borderRadius: 3 }}
            />
            <span className="text-text-secondary truncate" style={{ fontSize: 13 }}>{p.label}</span>
          </button>
        ))}
      </div>

      {/* Support */}
      <div className="px-3 mt-2">
        <div
          className="text-text-tertiary mb-1"
          style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase' }}
        >
          Support
        </div>
        {['Settings', 'Releases'].map((item) => (
          <button
            key={item}
            onClick={() => item === 'Settings' && onNavigate('settings')}
            className="w-full flex items-center gap-2.5 px-2.5 rounded-lg hover:bg-surface-hover transition-colors mb-0.5 cursor-pointer"
            style={{ height: 36 }}
          >
            <span className="text-text-secondary" style={{ fontSize: 13 }}>{item}</span>
          </button>
        ))}
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* User card */}
      <div className="p-3 border-t border-border">
        <div className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface-hover transition-colors cursor-pointer">
          <div
            className="flex-shrink-0 flex items-center justify-center rounded-full text-white font-semibold text-xs"
            style={{ width: 32, height: 32, background: '#F2622E' }}
          >
            CW
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-text-primary font-medium truncate" style={{ fontSize: 13 }}>Courtney Webb</div>
            <div className="text-text-tertiary truncate" style={{ fontSize: 11 }}>Operations Lead</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
            <circle cx="8" cy="4" r="0.5" fill="#9B9790" />
            <circle cx="8" cy="8" r="0.5" fill="#9B9790" />
            <circle cx="8" cy="12" r="0.5" fill="#9B9790" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function HomeIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 6.5L8 2l6 4.5V14a1 1 0 01-1 1H3a1 1 0 01-1-1V6.5z" />
      <path d="M6 15V9h4v6" />
    </svg>
  );
}

function TasksIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="12" height="11" rx="2" />
      <path d="M5 7l2 2 4-4" />
    </svg>
  );
}

function ForecastIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12l4-4 3 3 5-6" />
      <circle cx="14" cy="5" r="1.5" />
    </svg>
  );
}

function InboxIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 9h3.5l1.5 2h2l1.5-2H14" />
      <path d="M2 9V4a1 1 0 011-1h10a1 1 0 011 1v5" />
    </svg>
  );
}

function CalendarIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="12" height="12" rx="2" />
      <path d="M2 7h12M5 2v2M11 2v2" />
    </svg>
  );
}

function TeamIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="6" cy="5" r="2.5" />
      <path d="M1 14c0-2.76 2.24-5 5-5s5 2.24 5 5" />
      <circle cx="12" cy="5" r="2" />
      <path d="M15 14c0-2.21-1.34-4.1-3.25-4.75" />
    </svg>
  );
}

function DocsIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 2h6l4 4v8a1 1 0 01-1 1H3a1 1 0 01-1-1V3a1 1 0 011-1z" />
      <path d="M10 2v4h4M5 9h6M5 12h4" />
    </svg>
  );
}

function AutomationsIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 2L4 9h5l-2 5 7-7H9L9 2z" />
    </svg>
  );
}

function ReportingIcon({ active }: { active: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={active ? '#171614' : '#6B6862'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 13V9M7 13V5M11 13V8M15 13V3" />
    </svg>
  );
}

function ChevronIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
      <path d="M5 4l3 3-3 3" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="6" cy="6" r="4" />
      <path d="M9 9l3 3" />
    </svg>
  );
}
