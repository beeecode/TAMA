import { ReactNode } from 'react';

export function SparkleIcon({ size = 16, color = '#5F63C9' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M8 2l1.2 3.8L13 7l-3.8 1.2L8 12l-1.2-3.8L3 7l3.8-1.2L8 2z" fill={color} />
      <path d="M13 2l.7 2.3L16 5l-2.3.7L13 8l-.7-2.3L10 5l2.3-.7L13 2z" fill={color} opacity="0.6" />
    </svg>
  );
}

export function KPICard({
  label,
  value,
  description,
  footerIcon,
  footerText,
  footerColor = '#2F9E6B',
}: {
  label: string;
  value: string | number;
  description: string;
  footerIcon?: ReactNode;
  footerText?: string;
  footerColor?: string;
}) {
  return (
    <div
      className="flex flex-col bg-surface rounded-xl p-5"
      style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)', flex: 1 }}
    >
      <div
        className="text-text-tertiary uppercase mb-3"
        style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}
      >
        {label}
      </div>
      <div
        className="text-text-primary mb-1"
        style={{ fontSize: 30, fontWeight: 600, lineHeight: '34px', fontFamily: 'var(--font-tight)', fontVariantNumeric: 'tabular-nums' }}
      >
        {value}
      </div>
      <div className="text-text-secondary mb-4" style={{ fontSize: 13 }}>{description}</div>
      {footerText && (
        <div className="mt-auto pt-3 flex items-center gap-1.5" style={{ borderTop: '1px solid #E8E6E1' }}>
          {footerIcon}
          <span style={{ fontSize: 12, color: footerColor, fontWeight: 500 }}>{footerText}</span>
        </div>
      )}
    </div>
  );
}

export function StatusPill({
  status,
  size = 'md',
}: {
  status: 'on-track' | 'at-risk' | 'slipping' | 'pending';
  size?: 'sm' | 'md';
}) {
  const config = {
    'on-track': { bg: '#E8F7F1', color: '#2F9E6B', label: 'On track' },
    'at-risk': { bg: '#FDF5E3', color: '#E0A32E', label: 'At risk' },
    'slipping': { bg: '#FBECEC', color: '#D64545', label: 'Slipping' },
    'pending': { bg: '#F0EEEA', color: '#A39A90', label: 'Pending' },
  };
  const { bg, color, label } = config[status];
  return (
    <span
      className="inline-flex items-center rounded-full font-medium"
      style={{
        background: bg,
        color,
        fontSize: size === 'sm' ? 11 : 12,
        padding: size === 'sm' ? '2px 8px' : '3px 10px',
      }}
    >
      {label}
    </span>
  );
}

export function PageHeader({
  breadcrumb,
  title,
  children,
  tabs,
  activeTab,
  onTabChange,
}: {
  breadcrumb: string;
  title: string;
  children?: ReactNode;
  tabs?: string[];
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}) {
  return (
    <div className="mb-6">
      <div className="flex items-start justify-between mb-1">
        <div>
          <div className="text-text-tertiary mb-1" style={{ fontSize: 12 }}>{breadcrumb}</div>
          <h1
            className="text-text-primary"
            style={{ fontSize: 34, fontWeight: 600, lineHeight: '40px', fontFamily: 'var(--font-tight)', letterSpacing: '-0.005em', margin: 0 }}
          >
            {title}
          </h1>
        </div>
        {children && <div className="flex items-center gap-2 mt-2">{children}</div>}
      </div>
      {tabs && (
        <div className="flex items-center gap-6 mt-4" style={{ borderBottom: '1px solid #E8E6E1' }}>
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => onTabChange?.(tab)}
              className="pb-3 transition-colors cursor-pointer"
              style={{
                fontSize: 13,
                fontWeight: activeTab === tab ? 500 : 400,
                color: activeTab === tab ? '#171614' : '#6B6862',
                borderBottom: activeTab === tab ? '2px solid #171614' : '2px solid transparent',
                marginBottom: -1,
                background: 'none',
                border: 'none',
                borderBottomWidth: 2,
                borderBottomStyle: 'solid',
                borderBottomColor: activeTab === tab ? '#171614' : 'transparent',
              }}
            >
              {tab}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function ProposalCard({
  title,
  rationale,
  source,
  onApprove,
  onDismiss,
  compact = false,
}: {
  title: string;
  rationale: string;
  source: string;
  onApprove?: () => void;
  onDismiss?: () => void;
  compact?: boolean;
}) {
  return (
    <div
      className="rounded-xl p-4"
      style={{ background: '#EEEFFC', border: '1px solid #DCDDF8' }}
    >
      <div className="flex items-start gap-2 mb-2">
        <SparkleIcon size={14} />
        <span
          className="text-text-tertiary uppercase"
          style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}
        >
          {source}
        </span>
      </div>
      <div className="text-text-primary font-medium mb-1" style={{ fontSize: compact ? 12 : 13 }}>{title}</div>
      <div className="text-text-secondary mb-3" style={{ fontSize: 12 }}>{rationale}</div>
      <div className="flex items-center gap-2">
        <button
          onClick={onApprove}
          className="px-3 py-1 rounded-lg text-white font-medium transition-colors cursor-pointer"
          style={{ fontSize: 12, background: '#F2622E', border: 'none' }}
        >
          Approve
        </button>
        <button
          onClick={onDismiss}
          className="px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer"
          style={{ fontSize: 12, background: 'transparent', color: '#6B6862', border: '1px solid #D6D3CC' }}
        >
          Dismiss
        </button>
        {!compact && (
          <button className="px-2 py-1 text-ai-strong cursor-pointer" style={{ fontSize: 12, background: 'none', border: 'none' }}>
            Edit
          </button>
        )}
      </div>
    </div>
  );
}

export function Avatar({
  initials,
  color,
  size = 24,
}: {
  initials: string;
  color: string;
  size?: number;
}) {
  return (
    <div
      className="flex items-center justify-center rounded-full text-white font-semibold flex-shrink-0"
      style={{
        width: size,
        height: size,
        background: color,
        fontSize: size * 0.35,
        fontFamily: 'var(--font-tight)',
        border: '2px solid white',
      }}
    >
      {initials}
    </div>
  );
}

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  className = '',
}: {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'ai';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}) {
  const heightMap = { sm: 32, md: 40, lg: 48 };
  const paddingMap = { sm: '0 16px', md: '0 20px', lg: '0 24px' };
  const fontSizeMap = { sm: 12, md: 13, lg: 15 };

  const variantStyles = {
    primary: { background: '#F2622E', color: '#FFFFFF', border: 'none' },
    secondary: { background: '#FFFFFF', color: '#171614', border: '1px solid #D6D3CC' },
    ghost: { background: 'transparent', color: '#6B6862', border: '1px solid transparent' },
    ai: { background: '#EEEFFC', color: '#5F63C9', border: '1px solid #DCDDF8' },
  };

  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-lg font-medium transition-colors cursor-pointer ${className}`}
      style={{
        height: heightMap[size],
        padding: paddingMap[size],
        fontSize: fontSizeMap[size],
        fontFamily: 'var(--font-sans)',
        ...variantStyles[variant],
      }}
    >
      {children}
    </button>
  );
}

export function SectionCard({
  children,
  className = '',
  style = {},
}: {
  children: ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`bg-surface rounded-xl ${className}`}
      style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)', ...style }}
    >
      {children}
    </div>
  );
}
