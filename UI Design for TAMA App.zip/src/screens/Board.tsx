import { useState } from 'react';
import { ConfidenceChip } from '../components/ConfidenceBar';
import { PageHeader, Avatar, Button } from '../components/ui';

const COLUMNS = [
  {
    id: 'backlog',
    label: 'Backlog',
    dot: '#9B9790',
    tasks: [
      { title: 'Define Q4 OKR framework', project: 'Nimbus Dashboard', pColor: '#F97316', chip: 'P85 · 8 Apr', assignees: [{ i: 'SP', c: '#F97316' }], ai: false, comments: 3, attachments: 1 },
      { title: 'Audit legacy API endpoints', project: 'Orion API Gateway', pColor: '#3B82F6', chip: 'P95 · 15 Apr', assignees: [{ i: 'TK', c: '#22C55E' }], ai: true, comments: 0, attachments: 2 },
      { title: 'Research competitive positioning', project: 'Vega Brand Refresh', pColor: '#8B5CF6', chip: 'P85 · 12 Apr', assignees: [{ i: 'RK', c: '#8B5CF6' }, { i: 'CW', c: '#F2622E' }], ai: false, comments: 5, attachments: 0 },
      { title: 'Set up staging environment', project: 'Atlas CRM Revamp', pColor: '#22C55E', chip: 'P50 · 5 Apr', assignees: [{ i: 'AM', c: '#EC4899' }], ai: true, comments: 1, attachments: 3 },
    ],
  },
  {
    id: 'inprogress',
    label: 'In Progress',
    dot: '#F2622E',
    tasks: [
      { title: 'Finalize campaign brief for summer launch', project: 'Vega Brand Refresh', pColor: '#8B5CF6', chip: 'P85 · 22 Mar', assignees: [{ i: 'CW', c: '#F2622E' }, { i: 'AM', c: '#EC4899' }], ai: false, comments: 8, attachments: 2 },
      { title: 'Implement OAuth2 token refresh', project: 'Orion API Gateway', pColor: '#3B82F6', chip: 'P85 · 18 Mar', assignees: [{ i: 'TK', c: '#22C55E' }], ai: true, comments: 4, attachments: 1 },
      { title: 'Migrate contact data to new schema', project: 'Atlas CRM Revamp', pColor: '#22C55E', chip: 'P50 · 15 Mar', assignees: [{ i: 'SP', c: '#F97316' }], ai: false, comments: 12, attachments: 5 },
    ],
  },
  {
    id: 'review',
    label: 'In Review',
    dot: '#E0A32E',
    tasks: [
      { title: 'Stakeholder presentation deck', project: 'Nimbus Dashboard', pColor: '#F97316', chip: 'P85 · 25 Mar', assignees: [{ i: 'AM', c: '#EC4899' }, { i: 'RK', c: '#8B5CF6' }], ai: false, comments: 6, attachments: 4 },
      { title: 'API rate limiting specification', project: 'Orion API Gateway', pColor: '#3B82F6', chip: 'P50 · 20 Mar', assignees: [{ i: 'TK', c: '#22C55E' }], ai: true, comments: 2, attachments: 1 },
    ],
  },
  {
    id: 'done',
    label: 'Done',
    dot: '#2F9E6B',
    tasks: [
      { title: 'Design system token audit', project: 'Helio Task System', pColor: '#EC4899', chip: 'P50 · 10 Mar', assignees: [{ i: 'CW', c: '#F2622E' }], ai: false, comments: 3, attachments: 0 },
      { title: 'User interview synthesis report', project: 'Atlas CRM Revamp', pColor: '#22C55E', chip: 'P85 · 12 Mar', assignees: [{ i: 'RK', c: '#8B5CF6' }, { i: 'SP', c: '#F97316' }], ai: true, comments: 9, attachments: 6 },
      { title: 'Onboarding flow wireframes', project: 'Nimbus Dashboard', pColor: '#F97316', chip: 'P85 · 8 Mar', assignees: [{ i: 'AM', c: '#EC4899' }], ai: false, comments: 14, attachments: 7 },
    ],
  },
];

function MiniConfidenceBar() {
  return (
    <div className="w-full rounded-full overflow-hidden" style={{ height: 6, background: '#E8E6E1' }}>
      <div className="h-full" style={{ width: '35%', background: '#8B8FE8' }} />
      <div className="h-full" style={{ position: 'relative', top: -6, left: '35%', width: '30%', background: '#B9BCF0' }} />
      <div className="h-full" style={{ position: 'relative', top: -12, left: '65%', width: '35%', background: 'linear-gradient(to right, #DCDDF8, transparent)' }} />
    </div>
  );
}

function TaskCard({ task, lifted = false }: { task: typeof COLUMNS[0]['tasks'][0]; lifted?: boolean }) {
  return (
    <div
      className="bg-surface rounded-xl p-4 relative cursor-pointer transition-shadow"
      style={{
        border: `1px solid ${task.ai ? '#8B8FE8' : '#E8E6E1'}`,
        borderLeft: task.ai ? '3px solid #8B8FE8' : '1px solid #E8E6E1',
        boxShadow: lifted ? '0 16px 48px rgba(23,22,20,0.12)' : '0 1px 2px rgba(23,22,20,0.04)',
        transform: lifted ? 'rotate(2deg)' : 'none',
      }}
    >
      {task.ai && (
        <div className="absolute top-3 right-3">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
            <path d="M8 2l1.2 3.8L13 7l-3.8 1.2L8 12l-1.2-3.8L3 7l3.8-1.2L8 2z" fill="#8B8FE8" />
          </svg>
        </div>
      )}
      <div className="flex items-center gap-1.5 mb-2">
        <div className="rounded" style={{ width: 8, height: 8, background: task.pColor, borderRadius: 2 }} />
        <span className="text-text-tertiary" style={{ fontSize: 11, fontWeight: 500 }}>{task.project}</span>
      </div>
      <div className="text-text-primary mb-3 leading-snug" style={{ fontSize: 13, fontWeight: 500, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
        {task.title}
      </div>
      {/* Mini confidence bar */}
      <div className="mb-3">
        <MiniConfidenceBar />
      </div>
      <div className="flex items-center justify-between">
        <div className="flex -space-x-1.5">
          {task.assignees.map((a, i) => (
            <Avatar key={i} initials={a.i} color={a.c} size={22} />
          ))}
        </div>
        <div className="flex items-center gap-3">
          {task.comments > 0 && (
            <div className="flex items-center gap-1">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
                <path d="M1 1h10v7H6.5L4 10V8H1V1z" />
              </svg>
              <span className="text-text-tertiary" style={{ fontSize: 11 }}>{task.comments}</span>
            </div>
          )}
          {task.attachments > 0 && (
            <div className="flex items-center gap-1">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
                <path d="M10 6.5L5.5 11a3.5 3.5 0 01-5-5L6 1a2 2 0 013 3L3.5 9.5a.5.5 0 01-.7-.7L8 3.5" />
              </svg>
              <span className="text-text-tertiary" style={{ fontSize: 11 }}>{task.attachments}</span>
            </div>
          )}
          <ConfidenceChip label={task.chip} />
        </div>
      </div>
    </div>
  );
}

export default function Board() {
  const [activeTab, setActiveTab] = useState('Board');

  return (
    <div className="flex flex-col" style={{ height: '100%' }}>
      <PageHeader
        breadcrumb="Workspace / Tasks"
        title="Tasks"
        tabs={['Overview', 'Lists', 'Board', 'Timeline', 'Files']}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      >
        <Button variant="secondary" size="sm">Status: All</Button>
        <Button variant="primary" size="sm">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round">
            <path d="M7 3v8M3 7h8" />
          </svg>
          New task
        </Button>
      </PageHeader>

      <div className="flex gap-5 overflow-x-auto pb-4 flex-1" style={{ minHeight: 0 }}>
        {COLUMNS.map((col) => (
          <div
            key={col.id}
            className="flex flex-col rounded-xl"
            style={{ width: 320, flexShrink: 0, background: '#F5F4F1', padding: 12 }}
          >
            {/* Column header */}
            <div className="flex items-center justify-between mb-3 px-1">
              <div className="flex items-center gap-2">
                <div className="rounded-full" style={{ width: 8, height: 8, background: col.dot }} />
                <span className="text-text-primary font-semibold" style={{ fontSize: 14, fontFamily: 'var(--font-tight)' }}>{col.label}</span>
                <span className="text-text-tertiary" style={{ fontSize: 12 }}>{col.tasks.length}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button className="p-1 rounded hover:bg-surface-hover transition-colors cursor-pointer" style={{ background: 'none', border: 'none' }}>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
                    <path d="M7 3v8M3 7h8" />
                  </svg>
                </button>
                <button className="p-1 rounded hover:bg-surface-hover transition-colors cursor-pointer" style={{ background: 'none', border: 'none' }}>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round">
                    <circle cx="7" cy="3" r="0.5" fill="#9B9790" /><circle cx="7" cy="7" r="0.5" fill="#9B9790" /><circle cx="7" cy="11" r="0.5" fill="#9B9790" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Cards */}
            <div className="flex flex-col gap-2 overflow-y-auto flex-1">
              {col.tasks.map((task, i) => (
                <TaskCard key={i} task={task} lifted={col.id === 'inprogress' && i === 0} />
              ))}

              {/* Drop placeholder (shown in In Progress column) */}
              {col.id === 'inprogress' && (
                <div
                  className="rounded-xl"
                  style={{
                    height: 80,
                    border: '1.5px dashed #D6D3CC',
                    background: 'transparent',
                  }}
                />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
