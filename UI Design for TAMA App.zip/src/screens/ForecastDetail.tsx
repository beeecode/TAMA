import { useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, ReferenceLine,
} from 'recharts';
import { ConfidenceBar } from '../components/ConfidenceBar';
import { SparkleIcon, StatusPill, Button, SectionCard } from '../components/ui';

// Histogram data for distribution
const HISTOGRAM_DATA = Array.from({ length: 38 }, (_, i) => {
  const center = 18;
  const spread = 8;
  const x = i - center;
  const y = Math.round(400 * Math.exp(-(x * x) / (2 * spread * spread)) * (1 + (i > center ? 0.3 : -0.1)));
  return {
    date: `Mar ${5 + Math.floor(i * 0.7)}`,
    count: Math.max(0, y + Math.round((Math.random() - 0.5) * 60)),
    zone: i < 13 ? 'p50' : i < 24 ? 'p85' : 'p95',
  };
});

// P85 history
const HISTORY_DATA = [
  { week: 'Jan 13', p85: 'Mar 15', days: -13 },
  { week: 'Jan 20', p85: 'Mar 17', days: -11 },
  { week: 'Jan 27', p85: 'Mar 18', days: -10 },
  { week: 'Feb 3', p85: 'Mar 20', days: -8 },
  { week: 'Feb 10', p85: 'Mar 23', days: -5 },
  { week: 'Feb 17', p85: 'Mar 27', days: -1 },
  { week: 'Feb 24', p85: 'Mar 30', days: 2 },
  { week: 'Mar 3', p85: 'Apr 2', days: 5 },
].map(d => ({ ...d, committed: 0 }));

const FACTORS = [
  { label: 'Cycle time rising', value: '+4d', dir: 'up', icon: '↑' },
  { label: 'Two blocked approvals', value: '+3d', dir: 'up', icon: '↑' },
  { label: 'Scope added last cycle', value: '+6d', dir: 'up', icon: '↑' },
  { label: 'Team capacity down', value: '+2d', dir: 'up', icon: '↑' },
  { label: 'Velocity stable', value: '−1d', dir: 'down', icon: '↓' },
];

const PROPOSALS_MINI = [
  { title: 'Move two approvals to Sam', effect: 'recovers 3 days', actionLabel: 'Apply' },
  { title: 'Cut the microsite from scope', effect: 'recovers 6 days', actionLabel: 'Apply' },
  { title: 'Extend commitment to 4 April', effect: 'reaches P85', actionLabel: 'Apply' },
];

function DistributionBar({ datum }: { datum: typeof HISTOGRAM_DATA[0] }) {
  const colors = { p50: '#8B8FE8', p85: '#B9BCF0', p95: '#DCDDF8' };
  return (
    <div
      style={{
        flex: 1,
        background: colors[datum.zone as keyof typeof colors],
        height: `${Math.max(4, datum.count / 4)}px`,
        alignSelf: 'flex-end',
        borderRadius: '2px 2px 0 0',
        minHeight: 2,
      }}
    />
  );
}

export default function ForecastDetail() {
  const [isLearning, setIsLearning] = useState(false);

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="text-text-tertiary mb-1" style={{ fontSize: 12 }}>Workspace / Forecast</div>
          <div className="flex items-center gap-3">
            <h1 style={{ fontSize: 34, fontWeight: 600, fontFamily: 'var(--font-tight)', letterSpacing: '-0.005em', margin: 0, color: '#171614' }}>
              Vega Brand Refresh
            </h1>
            <StatusPill status="at-risk" />
          </div>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <button
            onClick={() => setIsLearning(!isLearning)}
            className="px-3 py-1.5 rounded-lg text-text-secondary transition-colors cursor-pointer"
            style={{ fontSize: 12, border: '1px solid #D6D3CC', background: '#FFFFFF' }}
          >
            {isLearning ? 'Switch to full data' : 'Preview learning state'}
          </button>
          <Button variant="secondary" size="sm">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
              <rect x="1" y="1" width="5" height="5" rx="1" /><rect x="8" y="1" width="5" height="5" rx="1" /><rect x="1" y="8" width="5" height="5" rx="1" /><rect x="8" y="8" width="5" height="5" rx="1" />
            </svg>
            Vega Brand Refresh
          </Button>
          <Button variant="secondary" size="sm">14 Mar – 12 Apr</Button>
          <Button variant="secondary" size="sm">Share forecast</Button>
        </div>
      </div>

      {/* Hero band */}
      <div
        className="rounded-2xl p-8"
        style={{
          background: isLearning ? '#EEEFFC' : '#FFFFFF',
          border: '1px solid #E8E6E1',
          boxShadow: '0 1px 2px rgba(23,22,20,0.04)',
        }}
      >
        {isLearning ? (
          /* Learning state */
          <div className="flex gap-12 items-start">
            <div>
              <div className="text-text-tertiary uppercase mb-4" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>
                Probability of hitting your committed date
              </div>
              <div className="flex items-center gap-4 mb-2">
                <span style={{ fontSize: 72, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#9B9790', lineHeight: 1 }}>—</span>
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-xl"
                  style={{ background: '#DCDDF8', border: '1px solid #B9BCF0' }}
                >
                  <SparkleIcon size={14} color="#8B8FE8" />
                  <span style={{ fontSize: 11, color: '#5F63C9', fontFamily: 'var(--font-mono)', fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                    Learning · 11 of 20 signals
                  </span>
                </div>
              </div>
              <div className="text-text-secondary" style={{ fontSize: 14 }}>
                TAMA needs 9 more completed tasks before it will quote odds.
              </div>
            </div>
            <div className="flex-1 mt-2">
              <div className="relative">
                <div className="w-full rounded-full overflow-hidden relative" style={{ height: 14, background: '#E8E6E1' }}>
                  <div className="absolute inset-0 hatch-overlay" />
                  <div style={{ width: '35%', height: '100%', background: 'rgba(139,143,232,0.4)' }} />
                </div>
              </div>
              <div className="text-text-tertiary mt-3" style={{ fontSize: 12 }}>
                Connect more completed work to improve signal quality.
              </div>
            </div>
          </div>
        ) : (
          /* Full data state */
          <div className="flex gap-12 items-start">
            <div style={{ minWidth: 240 }}>
              <div className="text-text-tertiary uppercase mb-4" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>
                Probability of hitting your committed date
              </div>
              <div style={{ fontSize: 72, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#E0A32E', lineHeight: 1, marginBottom: 8 }}>
                68%
              </div>
              <div className="text-text-secondary" style={{ fontSize: 13 }}>
                Committed 28 March · P85 lands 2 April
              </div>
            </div>
            <div className="flex-1">
              <ConfidenceBar
                p50Label="14 Mar"
                p85Label="2 Apr"
                p95Label="12 Apr"
                targetLabel="28 Mar"
                targetPosition={0.72}
                p50Position={0.32}
                p85Position={0.68}
                height={14}
              />
              <div className="flex items-center gap-6 mt-6" style={{ fontSize: 12 }}>
                <div className="flex items-center gap-2"><div className="rounded-full w-3 h-3" style={{ background: '#8B8FE8' }} /><span className="text-text-tertiary">P50 — optimistic</span></div>
                <div className="flex items-center gap-2"><div className="rounded-full w-3 h-3" style={{ background: '#B9BCF0' }} /><span className="text-text-tertiary">P85 — realistic</span></div>
                <div className="flex items-center gap-2"><div className="rounded-full w-3 h-3" style={{ background: '#DCDDF8' }} /><span className="text-text-tertiary">P95 — conservative</span></div>
                <div className="flex items-center gap-2"><div className="w-3 h-0.5" style={{ background: '#F2622E' }} /><span className="text-text-tertiary">Committed date</span></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Distribution chart */}
      <SectionCard style={{ padding: 20 }}>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 style={{ fontSize: 16, fontWeight: 600, fontFamily: 'var(--font-tight)', margin: 0 }}>Completion distribution</h3>
            <span className="text-text-tertiary" style={{ fontSize: 12 }}>(10,000 simulations)</span>
          </div>
          <div className="flex items-center gap-4">
            {[{ label: 'Before P50', color: '#8B8FE8' }, { label: 'P50–P85', color: '#B9BCF0' }, { label: 'P85–P95', color: '#DCDDF8' }].map(l => (
              <div key={l.label} className="flex items-center gap-1.5">
                <div className="rounded-full" style={{ width: 8, height: 8, background: l.color }} />
                <span className="text-text-tertiary" style={{ fontSize: 11 }}>{l.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-end gap-0.5" style={{ height: 160, position: 'relative' }}>
          {HISTOGRAM_DATA.map((d, i) => (
            <DistributionBar key={i} datum={d} />
          ))}
          {/* P50 marker */}
          <div className="absolute top-0 h-full" style={{ left: `${(13 / 38) * 100}%`, borderLeft: '1.5px dashed #8B8FE8' }}>
            <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: '#5F63C9', fontWeight: 500, position: 'absolute', top: 2, left: 4 }}>P50</span>
          </div>
          {/* P85 marker */}
          <div className="absolute top-0 h-full" style={{ left: `${(24 / 38) * 100}%`, borderLeft: '1.5px dashed #B9BCF0' }}>
            <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: '#5F63C9', fontWeight: 500, position: 'absolute', top: 2, left: 4 }}>P85</span>
          </div>
          {/* P95 marker */}
          <div className="absolute top-0 h-full" style={{ left: `${(34 / 38) * 100}%`, borderLeft: '1.5px dashed #DCDDF8' }}>
            <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: '#9B9790', fontWeight: 500, position: 'absolute', top: 2, left: 4 }}>P95</span>
          </div>
          {/* Committed date */}
          <div className="absolute top-0 h-full" style={{ left: '72%', borderLeft: '2px solid #F2622E' }}>
            <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: '#F2622E', fontWeight: 500, position: 'absolute', top: 2, left: 4 }}>28 Mar</span>
          </div>
        </div>
      </SectionCard>

      {/* Three-column detail */}
      <div className="grid gap-5" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
        {/* Factors */}
        <SectionCard style={{ padding: 20 }}>
          <h3 className="mb-4" style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-tight)', margin: '0 0 16px' }}>
            What's driving the forecast
          </h3>
          <div className="flex flex-col gap-3">
            {FACTORS.map((f, i) => (
              <div key={i} className="flex items-center gap-3">
                <div
                  className="rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ width: 28, height: 28, background: f.dir === 'up' ? '#FBECEC' : '#E8F7F1' }}
                >
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke={f.dir === 'up' ? '#D64545' : '#2F9E6B'} strokeWidth="1.5" strokeLinecap="round">
                    {f.dir === 'up'
                      ? <path d="M7 11V3M3 7l4-4 4 4" />
                      : <path d="M7 3v8M3 7l4 4 4-4" />
                    }
                  </svg>
                </div>
                <span className="flex-1 text-text-primary" style={{ fontSize: 13 }}>{f.label}</span>
                <span
                  style={{
                    fontSize: 12,
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 500,
                    color: f.dir === 'up' ? '#D64545' : '#2F9E6B',
                  }}
                >
                  {f.value}
                </span>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* History */}
        <SectionCard style={{ padding: 20 }}>
          <h3 className="mb-4" style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-tight)', margin: '0 0 16px' }}>
            P85 date history
          </h3>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={HISTORY_DATA}>
              <CartesianGrid vertical={false} stroke="#E8E6E1" strokeDasharray="3 0" />
              <XAxis dataKey="week" tick={{ fontSize: 9, fill: '#9B9790', fontFamily: 'var(--font-sans)' }} axisLine={false} tickLine={false} interval={1} />
              <YAxis tick={{ fontSize: 9, fill: '#9B9790', fontFamily: 'var(--font-sans)' }} axisLine={false} tickLine={false} domain={[-15, 10]} />
              <ReferenceLine y={0} stroke="#F2622E" strokeWidth={1.5} strokeDasharray="4 4" label={{ value: 'Committed', position: 'right', fill: '#F2622E', fontSize: 9 }} />
              <Line type="monotone" dataKey="days" stroke="#5F63C9" strokeWidth={2} dot={{ r: 3, fill: '#5F63C9', stroke: '#FFFFFF', strokeWidth: 1.5 }} />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-text-tertiary mt-2" style={{ fontSize: 11 }}>
            P85 date has slipped 5 days over 8 weeks.
          </p>
        </SectionCard>

        {/* What would fix it */}
        <SectionCard style={{ padding: 20 }}>
          <div className="flex items-center gap-2 mb-4">
            <SparkleIcon size={14} />
            <h3 style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-tight)', margin: 0 }}>
              What would fix it
            </h3>
          </div>
          <div className="flex flex-col gap-3">
            {PROPOSALS_MINI.map((p, i) => (
              <div
                key={i}
                className="rounded-xl p-3"
                style={{ background: '#EEEFFC', border: '1px solid #DCDDF8' }}
              >
                <div className="text-text-primary font-medium mb-1" style={{ fontSize: 12 }}>{p.title}</div>
                <div className="flex items-center justify-between">
                  <span className="text-on-track" style={{ fontSize: 11, fontFamily: 'var(--font-mono)' }}>
                    {p.effect}
                  </span>
                  <button
                    className="px-2 py-1 rounded text-ai-strong cursor-pointer"
                    style={{ fontSize: 11, background: 'none', border: '1px solid #B9BCF0' }}
                  >
                    {p.actionLabel}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
