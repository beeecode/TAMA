import { ProposalCard, Button, SectionCard } from '../components/ui';
import { SparkleIcon } from '../components/ui';

const PROPOSALS = [
  { title: 'Draft Q3 campaign kickoff task', rationale: '8 Slack messages reference campaign planning in #vega-brand this week', source: 'FROM SLACK' },
  { title: 'Schedule API security review', rationale: 'Auth spec meeting ran 45 min over — follow-up likely needed', source: 'FROM CALENDAR' },
  { title: 'Create CRM data migration checklist', rationale: '14 messages and 3 docs reference migration readiness', source: 'FROM SLACK' },
  { title: 'Brief stakeholders on new brand direction', rationale: 'Decision log shows 6 unanswered questions from last review', source: 'FROM TAMA' },
  { title: 'Set up weekly throughput review meeting', rationale: 'Forecast accuracy improves 12% for teams with weekly reviews', source: 'FROM TAMA' },
  { title: 'Update Nimbus Dashboard roadmap', rationale: '3 scope changes logged since last roadmap update 2 weeks ago', source: 'FROM TAMA' },
  { title: 'Sync with Tom on API gateway blockers', rationale: 'Tom has 2 tasks blocked for 3+ days. A sync typically unblocks within 1 day.', source: 'FROM TAMA' },
  { title: 'Write post-mortem for Q2 delivery slip', rationale: 'Orion API Gateway slipped by 8 days. Decision log has full context.', source: 'FROM TAMA' },
  { title: 'Review and close 5 stale tasks', rationale: '5 tasks have had no activity in 14+ days across 3 projects', source: 'FROM TAMA' },
  { title: 'Update project description for Helio', rationale: 'Description hasn\'t been updated since project start — 4 members added since', source: 'FROM TAMA' },
  { title: 'Send monthly forecast summary to leadership', rationale: 'Last sent 6 weeks ago. Q1 summary typically sent in week 2.', source: 'FROM TAMA' },
];

export default function Inbox() {
  return (
    <div>
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="text-text-tertiary mb-1" style={{ fontSize: 12 }}>Workspace</div>
          <div className="flex items-center gap-3">
            <h1 style={{ fontSize: 34, fontWeight: 600, fontFamily: 'var(--font-tight)', letterSpacing: '-0.005em', margin: 0, color: '#171614' }}>Inbox</h1>
            <span
              className="rounded-full text-white flex items-center justify-center"
              style={{ background: '#8B8FE8', fontSize: 12, fontWeight: 600, minWidth: 22, height: 22, padding: '0 6px', fontFamily: 'var(--font-mono)' }}
            >
              11
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <Button variant="secondary" size="sm">Approve all</Button>
          <Button variant="ghost" size="sm">Dismiss all</Button>
        </div>
      </div>

      {/* AI context banner */}
      <div
        className="flex items-start gap-3 rounded-xl p-4 mb-6"
        style={{ background: '#EEEFFC', border: '1px solid #DCDDF8' }}
      >
        <SparkleIcon size={16} />
        <div>
          <div className="text-ai-strong font-medium mb-0.5" style={{ fontSize: 13 }}>TAMA reviewed your workspace</div>
          <div className="text-text-secondary" style={{ fontSize: 13 }}>
            Scanned 48 Slack messages, 6 calendar events, and 12 task updates from the past 48 hours. Found 11 items that may need your attention.
          </div>
        </div>
      </div>

      <div className="grid gap-4" style={{ gridTemplateColumns: '1fr 1fr' }}>
        {PROPOSALS.map((p, i) => (
          <ProposalCard key={i} {...p} />
        ))}
      </div>
    </div>
  );
}
