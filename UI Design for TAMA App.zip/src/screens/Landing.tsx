import { useState } from 'react';
import { ConfidenceBar } from '../components/ConfidenceBar';
import { SparkleIcon, Button } from '../components/ui';

interface LandingProps {
  onNavigate: (screen: string) => void;
}

export default function Landing({ onNavigate }: LandingProps) {
  const [faqOpen, setFaqOpen] = useState<number | null>(0);
  const [scrolled] = useState(false);

  const faqs = [
    { q: 'How does TAMA calculate confidence levels?', a: 'TAMA runs Monte Carlo simulations using your team\'s historical cycle times — the time it actually took to complete similar work. It needs at least 20 completed items per workstream to quote reliable odds. Until then, it shows a transparent "still learning" state.' },
    { q: 'What data does TAMA need to connect?', a: 'Two sources minimum: a calendar (Google Calendar or Outlook) and one task tool (Asana, Jira, Notion, or Linear). More connections refine the forecast, but you get a working forecast from two.' },
    { q: 'Will TAMA replace our project management tool?', a: 'No. TAMA reads from your existing tools and adds a probability layer on top. Your team keeps working where they already work.' },
    { q: 'How is this different from AI assistants that estimate tasks?', a: 'AI assistants estimate the future based on assumptions. TAMA measures your past and simulates your future. The difference is the difference between a guess and actuarial math.' },
    { q: 'Can managers see individual employee data?', a: 'Workload and capacity data is visible. Raw activity logs are not surfaced to managers by default. Admins control granularity in Settings → Privacy.' },
    { q: 'What happens when the forecast is wrong?', a: 'Every slip is logged with its cause. Over time, TAMA\'s accuracy improves as it learns your team\'s patterns. The decision log shows you what changed and when.' },
  ];

  return (
    <div className="min-h-screen" style={{ background: '#FAFAF8' }}>
      {/* Nav */}
      <nav
        className="sticky top-0 z-50 flex items-center justify-between px-16"
        style={{
          height: 72,
          background: scrolled ? 'rgba(250,250,248,0.85)' : '#FAFAF8',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid transparent',
          transition: 'all 0.18s',
        }}
      >
        <div className="flex items-center gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('landing')}>
            <div
              className="flex items-center justify-center rounded-lg text-white font-bold"
              style={{ width: 28, height: 28, background: '#5F63C9', fontFamily: 'var(--font-tight)', fontSize: 14 }}
            >
              T
            </div>
            <span style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 22, letterSpacing: '-0.02em', color: '#171614' }}>
              TAMA
            </span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            {['Product', 'Forecasting', 'Pricing', 'Docs', 'Company'].map(link => (
              <a key={link} href="#" className="text-text-secondary hover:text-text-primary transition-colors" style={{ fontSize: 14 }}>
                {link}
              </a>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => onNavigate('signin')}>Sign in</Button>
          <Button variant="primary" size="sm" onClick={() => onNavigate('signup')}>Start free</Button>
        </div>
      </nav>

      {/* Hero */}
      <section className="px-20 pt-32 pb-24">
        <div className="max-w-screen-xl mx-auto">
          <div className="grid gap-16" style={{ gridTemplateColumns: '7fr 5fr' }}>
            {/* Left */}
            <div className="flex flex-col">
              {/* Eyebrow */}
              <div
                className="inline-flex items-center gap-2 rounded-full mb-8 self-start"
                style={{ background: '#EEEFFC', padding: '6px 14px' }}
              >
                <SparkleIcon size={12} />
                <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: '0.06em', color: '#5F63C9', textTransform: 'uppercase' }}>
                  Forecasting, not deadlines
                </span>
              </div>

              <h1
                style={{
                  fontFamily: 'var(--font-tight)',
                  fontWeight: 600,
                  fontSize: 60,
                  lineHeight: '64px',
                  color: '#171614',
                  letterSpacing: '-0.015em',
                  maxWidth: 620,
                  margin: '0 0 24px',
                }}
              >
                Stop promising dates. Start quoting odds.
              </h1>

              <p
                className="text-text-secondary mb-8"
                style={{ fontSize: 18, lineHeight: '28px', maxWidth: 540 }}
              >
                TAMA reads how your team actually delivers, then tells you the probability of hitting any date — before you commit to it.
              </p>

              <div className="flex items-center gap-3 mb-6">
                <Button variant="primary" size="lg" onClick={() => onNavigate('signup')}>Start free</Button>
                <Button variant="secondary" size="lg">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="7" stroke="#6B6862" strokeWidth="1.5" />
                    <path d="M6.5 5.5l5 2.5-5 2.5V5.5z" fill="#6B6862" />
                  </svg>
                  See a live forecast
                </Button>
              </div>

              <p className="text-text-tertiary" style={{ fontSize: 13 }}>
                No setup. Connect two tools, get a working workspace in ninety seconds.
              </p>
            </div>

            {/* Right — product fragment */}
            <div className="flex items-center justify-center">
              <div
                className="w-full"
                style={{
                  background: '#FFFFFF',
                  borderRadius: 20,
                  padding: 28,
                  border: '1px solid #E8E6E1',
                  boxShadow: '0 16px 48px rgba(23,22,20,0.12), 0 2px 8px rgba(23,22,20,0.06)',
                }}
              >
                <div className="text-text-tertiary mb-2" style={{ fontSize: 11, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  Q3 Campaign Launch · Vega Brand Refresh
                </div>
                <div className="text-text-primary font-semibold mb-6" style={{ fontSize: 16, fontFamily: 'var(--font-tight)' }}>
                  Summer Campaign Go-live
                </div>

                <div className="mb-8">
                  <ConfidenceBar
                    p50Label="14 Mar"
                    p85Label="22 Mar"
                    p95Label="28 Mar"
                    targetLabel="28 Mar"
                    targetPosition={0.91}
                    p50Position={0.35}
                    p85Position={0.70}
                    height={12}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div
                      className="text-at-risk"
                      style={{ fontSize: 40, fontWeight: 600, fontFamily: 'var(--font-mono)', lineHeight: 1 }}
                    >
                      68%
                    </div>
                    <div className="text-text-secondary mt-1" style={{ fontSize: 13 }}>
                      likely to hit your date
                    </div>
                  </div>
                  <div
                    className="flex items-center gap-2 px-3 py-2 rounded-xl"
                    style={{ background: '#EEEFFC', border: '1px solid #DCDDF8' }}
                  >
                    <SparkleIcon size={14} />
                    <span style={{ fontSize: 12, color: '#5F63C9', fontFamily: 'var(--font-mono)', fontWeight: 500 }}>
                      P85 · 22 Mar
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-4" style={{ borderTop: '1px solid #E8E6E1' }}>
                  <p className="text-ai-strong font-medium" style={{ fontSize: 13 }}>
                    "68% likely to hit your date."
                  </p>
                  <p className="text-text-tertiary mt-0.5" style={{ fontSize: 11 }}>
                    Based on 312 completed tasks · 10,000 simulations
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Logo strip */}
      <section className="px-20 py-16" style={{ borderTop: '1px solid #E8E6E1', borderBottom: '1px solid #E8E6E1' }}>
        <div className="max-w-screen-xl mx-auto text-center">
          <p className="text-text-tertiary mb-8 uppercase" style={{ fontSize: 11, fontWeight: 500, letterSpacing: '0.06em' }}>
            Trusted by operations teams at
          </p>
          <div className="flex items-center justify-center gap-12 flex-wrap">
            {['Meridian', 'Solstice', 'Arcform', 'Northline', 'Vertex'].map(name => (
              <span
                key={name}
                className="text-text-tertiary font-semibold"
                style={{ fontSize: 18, opacity: 0.35, fontFamily: 'var(--font-tight)', letterSpacing: '-0.01em' }}
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Problem section */}
      <section className="px-20 py-32">
        <div className="max-w-screen-xl mx-auto text-center">
          <h2
            className="text-text-primary mb-16"
            style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '48px', letterSpacing: '-0.01em' }}
          >
            Every deadline in your workspace is a guess.
          </h2>

          <div className="grid grid-cols-3 gap-12 mb-16">
            {[
              { num: '88%', desc: 'of the most AI-productive workers report burnout.', attr: 'Upwork Research Institute', color: '#D64545' },
              { num: '3 in 5', desc: 'US workers say their workload grew after AI adoption.', attr: 'SHRM, 2026', color: '#E0A32E' },
              { num: '39%', desc: 'of AI users now spend more time reviewing AI output.', attr: 'Upwork Research Institute', color: '#E0A32E' },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center">
                <div
                  style={{
                    fontSize: 56,
                    fontWeight: 600,
                    fontFamily: 'var(--font-mono)',
                    color: stat.color,
                    lineHeight: 1,
                    marginBottom: 16,
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {stat.num}
                </div>
                <p className="text-text-primary mb-3" style={{ fontSize: 16, lineHeight: '26px' }}>{stat.desc}</p>
                <p className="text-text-tertiary" style={{ fontSize: 12 }}>— {stat.attr}</p>
              </div>
            ))}
          </div>

          <p className="text-text-secondary mx-auto" style={{ fontSize: 18, lineHeight: '28px', maxWidth: 680 }}>
            Faster tools didn't fix planning. They just made the guessing quicker.
          </p>
        </div>
      </section>

      {/* How it works */}
      <section style={{ background: '#F5F4F1', borderRadius: 32, margin: '0 32px', padding: '80px 64px' }}>
        <div className="max-w-screen-xl mx-auto">
          <h2
            className="text-text-primary mb-16 text-center"
            style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '48px', letterSpacing: '-0.01em' }}
          >
            Three steps. Ninety seconds.
          </h2>
          <div className="grid grid-cols-3 gap-6">
            {[
              {
                n: '01',
                title: 'Connect',
                desc: 'Point TAMA at the tools your team already uses. Calendar, Slack, Drive, your task tool. No migration, no setup ceremony.',
              },
              {
                n: '02',
                title: 'Learn',
                desc: 'TAMA reads completed work and measures your real cycle times. No story points. No estimation sessions. No ceremony.',
              },
              {
                n: '03',
                title: 'Forecast',
                desc: 'Every date becomes a probability. Every commitment becomes a decision you can defend with data, not optimism.',
              },
            ].map((step) => (
              <div
                key={step.n}
                className="bg-surface rounded-2xl p-8"
                style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)' }}
              >
                <div
                  className="mb-4"
                  style={{ fontSize: 13, fontFamily: 'var(--font-mono)', color: '#8B8FE8', fontWeight: 500 }}
                >
                  {step.n}
                </div>
                <h3
                  className="text-text-primary mb-3"
                  style={{ fontSize: 20, fontWeight: 600, fontFamily: 'var(--font-tight)' }}
                >
                  {step.title}
                </h3>
                <p className="text-text-secondary" style={{ fontSize: 14, lineHeight: '22px' }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Flagship feature */}
      <section className="px-20 py-32">
        <div className="max-w-screen-xl mx-auto">
          <h2
            className="text-text-primary mb-4"
            style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '52px', letterSpacing: '-0.01em', maxWidth: 720 }}
          >
            A due date tells you nothing. A distribution tells you everything.
          </h2>
          <p className="text-text-secondary mb-12" style={{ fontSize: 18, lineHeight: '28px', maxWidth: 620 }}>
            TAMA replaces single-point deadlines with probability distributions built from your team's real delivery history.
          </p>

          {/* Product screenshot mockup */}
          <div
            className="rounded-2xl overflow-hidden mb-12"
            style={{
              border: '1px solid #E8E6E1',
              boxShadow: '0 16px 48px rgba(23,22,20,0.12), 0 2px 8px rgba(23,22,20,0.06)',
              background: '#FAFAF8',
              padding: 32,
            }}
          >
            {/* Mini forecast detail preview */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-text-tertiary mb-1" style={{ fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 500 }}>
                  Probability of hitting your committed date
                </div>
                <span style={{ fontSize: 72, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#E0A32E', lineHeight: 1 }}>68%</span>
                <div className="text-text-secondary mt-1" style={{ fontSize: 13 }}>Committed 28 March · P85 lands 2 April</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-3 py-1.5 rounded-full bg-at-risk/10" style={{ background: '#FDF5E3' }}>
                  <span style={{ fontSize: 12, color: '#E0A32E', fontWeight: 500 }}>At risk</span>
                </div>
              </div>
            </div>
            <ConfidenceBar
              p50Label="14 Mar"
              p85Label="2 Apr"
              p95Label="12 Apr"
              targetLabel="28 Mar"
              targetPosition={0.72}
              p50Position={0.32}
              p85Position={0.68}
              height={14}
            />
          </div>

          <div className="grid grid-cols-3 gap-8">
            {[
              { icon: '◎', title: 'P50, P85, P95', desc: 'See the optimistic, the realistic and the safe date at once — never just one number.' },
              { icon: '◈', title: 'Built from your history', desc: 'Simulations run on your team\'s actual throughput, not estimates or story points.' },
              { icon: '◫', title: 'Honest when it\'s new', desc: 'TAMA shows you when it\'s still learning instead of bluffing with insufficient data.' },
            ].map((f) => (
              <div key={f.title} className="flex gap-4">
                <div className="text-ai-strong mt-0.5" style={{ fontSize: 20, flexShrink: 0 }}>{f.icon}</div>
                <div>
                  <div className="text-text-primary font-semibold mb-1" style={{ fontSize: 15, fontFamily: 'var(--font-tight)' }}>{f.title}</div>
                  <div className="text-text-secondary" style={{ fontSize: 13, lineHeight: '20px' }}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Secondary features */}
      <section className="px-20 py-24">
        <div className="max-w-screen-xl mx-auto">
          <h2
            className="text-text-primary mb-12 text-center"
            style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '48px', letterSpacing: '-0.01em' }}
          >
            Everything else, handled quietly.
          </h2>
          <div className="grid grid-cols-3 gap-5" style={{ gridTemplateRows: 'auto auto' }}>
            {[
              { title: 'Proposal Inbox', desc: 'TAMA drafts tasks from your meetings and messages. You approve or dismiss in one click.' },
              { title: 'Live status', desc: 'Status updates itself from real activity. Nobody writes a standup again.' },
              { title: 'Team load', desc: 'See who\'s underwater before they tell you. Rebalancing suggestions surface automatically.' },
              { title: 'Decision log', desc: 'Every slip, scope change and reassignment recorded with its cause. Accountability without blame.' },
              { title: 'Automations', desc: 'Rules for the predictable. Agents for the rest. Neither requires an engineer.' },
              { title: 'Ask TAMA', desc: 'Plain-language questions across every project, doc and thread. Answers in seconds.' },
            ].map((f) => (
              <div
                key={f.title}
                className="bg-surface rounded-xl p-7"
                style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)' }}
              >
                <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-4" style={{ background: '#EEEFFC' }}>
                  <SparkleIcon size={16} />
                </div>
                <div className="text-text-primary font-semibold mb-2" style={{ fontSize: 16, fontFamily: 'var(--font-tight)' }}>{f.title}</div>
                <div className="text-text-secondary" style={{ fontSize: 13, lineHeight: '20px' }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-24" style={{ background: '#F5F4F1' }}>
        <div className="max-w-screen-xl mx-auto px-20 text-center">
          <p
            className="text-text-primary mx-auto mb-8"
            style={{
              fontFamily: 'var(--font-tight)',
              fontSize: 28,
              fontWeight: 600,
              lineHeight: '36px',
              maxWidth: 780,
              letterSpacing: '-0.005em',
            }}
          >
            "TAMA changed how we have deadline conversations entirely. We stopped saying 'we'll be done by Friday' and started saying '80% confidence by Friday.' Our stakeholders actually trust us more."
          </p>
          <div className="flex items-center justify-center gap-3">
            <div
              className="flex items-center justify-center rounded-full text-white font-semibold"
              style={{ width: 40, height: 40, background: '#3B82F6', fontSize: 14, fontFamily: 'var(--font-tight)' }}
            >
              RK
            </div>
            <div className="text-left">
              <div className="text-text-primary font-semibold" style={{ fontSize: 14 }}>Rachel Kim</div>
              <div className="text-text-tertiary" style={{ fontSize: 12 }}>Head of Operations, Solstice Health</div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="px-20 py-32">
        <div className="max-w-screen-xl mx-auto">
          <div className="text-center mb-4">
            <h2
              className="text-text-primary"
              style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '48px', letterSpacing: '-0.01em' }}
            >
              Priced per seat. Never per credit.
            </h2>
          </div>
          <p className="text-text-secondary text-center mb-16" style={{ fontSize: 16 }}>No AI credits. No metered surprises.</p>

          <div className="flex gap-6 justify-center">
            {[
              {
                name: 'Starter',
                price: '0',
                desc: 'For small teams exploring probability-driven planning.',
                features: ['Up to 10 people', '2 active projects', 'Basic forecasting', '14-day history', 'Google Calendar integration', 'Community support'],
                btn: 'Get started free',
                btnVariant: 'secondary' as const,
                featured: false,
              },
              {
                name: 'Team',
                price: '14',
                desc: 'Full confidence forecasting for growing teams.',
                features: ['Unlimited projects', 'Full confidence forecasting', 'Proposal inbox', 'All integrations', 'Decision log', 'Email support'],
                btn: 'Start free trial',
                btnVariant: 'primary' as const,
                featured: true,
              },
              {
                name: 'Scale',
                price: '28',
                desc: 'Portfolio-level certainty for complex operations.',
                features: ['Portfolio forecasting', 'SSO & SAML', 'Audit log', 'Custom integrations', 'SLA & uptime guarantee', 'Priority support'],
                btn: 'Contact sales',
                btnVariant: 'secondary' as const,
                featured: false,
              },
            ].map((plan) => (
              <div
                key={plan.name}
                className="flex flex-col rounded-2xl p-8"
                style={{
                  width: 380,
                  background: '#FFFFFF',
                  border: plan.featured ? '2px solid #8B8FE8' : '1px solid #E8E6E1',
                  boxShadow: plan.featured ? '0 4px 12px rgba(139,143,232,0.15)' : '0 1px 2px rgba(23,22,20,0.04)',
                  position: 'relative',
                }}
              >
                {plan.featured && (
                  <div
                    className="absolute -top-px left-8 px-3 py-1 rounded-b-lg"
                    style={{ background: '#EEEFFC', fontSize: 10, fontWeight: 500, color: '#5F63C9', letterSpacing: '0.06em', textTransform: 'uppercase' }}
                  >
                    Most Popular
                  </div>
                )}
                <div className="text-text-primary font-semibold mb-1" style={{ fontSize: 18, fontFamily: 'var(--font-tight)' }}>{plan.name}</div>
                <div className="flex items-end gap-1 mb-3">
                  {plan.price === '0' ? (
                    <span style={{ fontSize: 40, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#171614', lineHeight: 1 }}>Free</span>
                  ) : (
                    <>
                      <span style={{ fontSize: 16, color: '#6B6862', alignSelf: 'flex-start', marginTop: 8 }}>$</span>
                      <span style={{ fontSize: 40, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#171614', lineHeight: 1 }}>{plan.price}</span>
                      <span className="text-text-tertiary mb-1" style={{ fontSize: 13 }}>/user/mo</span>
                    </>
                  )}
                </div>
                <p className="text-text-secondary mb-6" style={{ fontSize: 13, lineHeight: '20px' }}>{plan.desc}</p>
                <div style={{ borderTop: '1px solid #E8E6E1', marginBottom: 20 }} />
                <div className="flex flex-col gap-3 mb-8 flex-1">
                  {plan.features.map(f => (
                    <div key={f} className="flex items-center gap-2">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <circle cx="8" cy="8" r="7" fill={plan.featured ? '#EEEFFC' : '#E8F7F1'} />
                        <path d="M5 8l2 2 4-4" stroke={plan.featured ? '#5F63C9' : '#2F9E6B'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      <span className="text-text-secondary" style={{ fontSize: 13 }}>{f}</span>
                    </div>
                  ))}
                </div>
                <Button variant={plan.btnVariant} size="md" className="w-full justify-center" onClick={() => onNavigate('signup')}>
                  {plan.btn}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="px-20 py-24" style={{ borderTop: '1px solid #E8E6E1' }}>
        <div className="max-w-screen-xl mx-auto grid" style={{ gridTemplateColumns: '1fr 2fr', gap: 80 }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 36, color: '#171614', letterSpacing: '-0.01em' }}>
              Questions
            </h2>
          </div>
          <div>
            {faqs.map((faq, i) => (
              <div key={i} style={{ borderTop: '1px solid #E8E6E1' }}>
                <button
                  className="w-full flex items-center justify-between py-5 cursor-pointer"
                  style={{ background: 'none', border: 'none', textAlign: 'left' }}
                  onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                >
                  <span className="text-text-primary font-medium" style={{ fontSize: 15 }}>{faq.q}</span>
                  <svg
                    width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#9B9790" strokeWidth="1.5" strokeLinecap="round"
                    style={{ flexShrink: 0, transform: faqOpen === i ? 'rotate(45deg)' : 'rotate(0deg)', transition: 'transform 0.18s' }}
                  >
                    <path d="M8 3v10M3 8h10" />
                  </svg>
                </button>
                {faqOpen === i && (
                  <div className="pb-5 text-text-secondary animate-fade-in" style={{ fontSize: 14, lineHeight: '22px' }}>
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section style={{ background: '#F5F4F1', borderRadius: 32, margin: '0 32px 80px', padding: '80px 64px', textAlign: 'center' }}>
        <h2
          className="text-text-primary mx-auto mb-8"
          style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 44, lineHeight: '48px', letterSpacing: '-0.01em', maxWidth: 600 }}
        >
          Know the odds before you promise.
        </h2>
        <div className="flex items-center justify-center gap-4">
          <Button variant="primary" size="lg" onClick={() => onNavigate('signup')}>Start free</Button>
          <Button variant="secondary" size="lg">Book a walkthrough</Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-20 pt-20 pb-12" style={{ borderTop: '1px solid #E8E6E1' }}>
        <div className="max-w-screen-xl mx-auto">
          <div className="grid grid-cols-5 gap-8 mb-16">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex items-center justify-center rounded-lg text-white font-bold" style={{ width: 24, height: 24, background: '#5F63C9', fontSize: 12 }}>T</div>
                <span style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 18, color: '#171614' }}>TAMA</span>
              </div>
              <p className="text-text-tertiary mb-4" style={{ fontSize: 13, lineHeight: '20px' }}>Probability-native work management for operations teams.</p>
              <div className="flex gap-3">
                {['X', 'Li', 'Gh'].map(s => (
                  <div key={s} className="w-8 h-8 rounded-lg bg-surface-sunk flex items-center justify-center text-text-tertiary" style={{ fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>{s}</div>
                ))}
              </div>
            </div>
            {[
              { head: 'Product', links: ['Features', 'Forecasting', 'Integrations', 'Changelog', 'Status'] },
              { head: 'Resources', links: ['Docs', 'API Reference', 'Blog', 'Community', 'Templates'] },
              { head: 'Company', links: ['About', 'Careers', 'Press', 'Contact', 'Partners'] },
              { head: 'Legal', links: ['Privacy', 'Terms', 'Security', 'Cookies', 'DPA'] },
            ].map(col => (
              <div key={col.head}>
                <div className="text-text-primary font-semibold mb-4" style={{ fontSize: 13 }}>{col.head}</div>
                {col.links.map(link => (
                  <div key={link} className="text-text-tertiary hover:text-text-secondary mb-2 cursor-pointer transition-colors" style={{ fontSize: 13 }}>{link}</div>
                ))}
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between pt-6" style={{ borderTop: '1px solid #E8E6E1' }}>
            <span className="text-text-tertiary" style={{ fontSize: 12 }}>© 2026 TAMA Inc. All rights reserved.</span>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#2F9E6B' }} />
              <span className="text-text-tertiary" style={{ fontSize: 12 }}>All systems operational</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
