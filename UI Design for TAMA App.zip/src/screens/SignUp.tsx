import { ConfidenceBar } from '../components/ConfidenceBar';
import { Button, SparkleIcon } from '../components/ui';

interface SignUpProps {
  mode: 'signup' | 'signin';
  onNavigate: (screen: string) => void;
}

export default function SignUp({ mode, onNavigate }: SignUpProps) {
  return (
    <div className="min-h-screen grid" style={{ gridTemplateColumns: '1fr 1fr', background: '#FAFAF8' }}>
      {/* Left */}
      <div className="flex flex-col items-center justify-center px-16">
        <div className="w-full" style={{ maxWidth: 400 }}>
          {/* Logo */}
          <div className="flex items-center gap-2 mb-10 cursor-pointer" onClick={() => onNavigate('landing')}>
            <div className="flex items-center justify-center rounded-lg text-white font-bold" style={{ width: 28, height: 28, background: '#5F63C9', fontFamily: 'var(--font-tight)', fontSize: 14 }}>T</div>
            <span style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 20, letterSpacing: '-0.02em', color: '#171614' }}>TAMA</span>
          </div>

          <h1 style={{ fontFamily: 'var(--font-tight)', fontWeight: 600, fontSize: 28, letterSpacing: '-0.005em', margin: '0 0 8px', color: '#171614' }}>
            {mode === 'signup' ? 'Create your workspace' : 'Welcome back'}
          </h1>
          <p className="text-text-secondary mb-8" style={{ fontSize: 14 }}>
            {mode === 'signup' ? 'Get your first forecast in 90 seconds.' : 'Sign in to your workspace.'}
          </p>

          {/* SSO */}
          <div className="flex flex-col gap-3 mb-6">
            {[
              { name: 'Google', icon: 'G', bg: '#4285F4' },
              { name: 'Microsoft', icon: 'M', bg: '#00A4EF' },
              { name: 'Slack', icon: 'S', bg: '#4A154B' },
            ].map(sso => (
              <button
                key={sso.name}
                className="w-full flex items-center gap-3 rounded-lg transition-colors cursor-pointer"
                style={{ height: 44, background: '#FFFFFF', border: '1px solid #D6D3CC', padding: '0 16px', fontSize: 14, color: '#171614' }}
              >
                <div className="flex items-center justify-center rounded font-bold text-white" style={{ width: 22, height: 22, background: sso.bg, fontSize: 12, fontFamily: 'var(--font-tight)' }}>
                  {sso.icon}
                </div>
                <span>Continue with {sso.name}</span>
              </button>
            ))}
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px" style={{ background: '#E8E6E1' }} />
            <span className="text-text-tertiary" style={{ fontSize: 13 }}>or</span>
            <div className="flex-1 h-px" style={{ background: '#E8E6E1' }} />
          </div>

          {/* Fields */}
          <div className="flex flex-col gap-4 mb-6">
            <div>
              <label className="text-text-tertiary uppercase mb-1.5 block" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>Email</label>
              <input
                type="email"
                placeholder="courtney@company.com"
                className="w-full rounded-lg px-3 outline-none text-text-primary"
                style={{ height: 40, border: '1px solid #D6D3CC', fontSize: 13, background: '#FFFFFF' }}
              />
            </div>
            <div>
              <label className="text-text-tertiary uppercase mb-1.5 block" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>Password</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full rounded-lg px-3 outline-none text-text-primary"
                style={{ height: 40, border: '1px solid #D6D3CC', fontSize: 13, background: '#FFFFFF' }}
              />
              {mode === 'signup' && (
                <div className="flex gap-1 mt-2">
                  {[1, 2, 3, 4].map(seg => (
                    <div key={seg} className="flex-1 h-1 rounded-full" style={{ background: seg <= 2 ? '#8B8FE8' : '#E8E6E1' }} />
                  ))}
                </div>
              )}
              {mode === 'signin' && (
                <div className="text-right mt-1.5">
                  <a href="#" className="text-text-tertiary hover:text-text-secondary" style={{ fontSize: 12 }}>Forgot password?</a>
                </div>
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('onboarding')}
            className="w-full rounded-lg text-white font-medium transition-colors cursor-pointer"
            style={{ height: 40, background: '#F2622E', border: 'none', fontSize: 14, fontFamily: 'var(--font-sans)' }}
          >
            Continue
          </button>

          <p className="text-text-tertiary text-center mt-4" style={{ fontSize: 12 }}>
            By continuing, you agree to our{' '}
            <a href="#" className="underline">Terms</a> and{' '}
            <a href="#" className="underline">Privacy Policy</a>.
          </p>

          <p className="text-text-secondary text-center mt-4" style={{ fontSize: 13 }}>
            {mode === 'signup' ? (
              <>Already have an account? <button onClick={() => onNavigate('signin')} className="text-action font-medium cursor-pointer" style={{ background: 'none', border: 'none', padding: 0 }}>Sign in</button></>
            ) : (
              <>No account? <button onClick={() => onNavigate('signup')} className="text-action font-medium cursor-pointer" style={{ background: 'none', border: 'none', padding: 0 }}>Create workspace</button></>
            )}
          </p>
        </div>
      </div>

      {/* Right */}
      <div
        className="flex flex-col items-center justify-center gap-6 px-16"
        style={{ background: '#F5F4F1', borderLeft: '1px solid #E8E6E1' }}
      >
        <div className="flex flex-col gap-5 relative" style={{ width: 380 }}>
          {/* Confidence bar card */}
          <div
            className="rounded-2xl p-6 bg-surface"
            style={{ border: '1px solid #E8E6E1', boxShadow: '0 4px 12px rgba(23,22,20,0.06)', transform: 'translateY(0)' }}
          >
            <div className="flex items-center gap-2 mb-1">
              <div className="rounded" style={{ width: 8, height: 8, background: '#8B5CF6', borderRadius: 2 }} />
              <span className="text-text-tertiary" style={{ fontSize: 11 }}>Vega Brand Refresh</span>
            </div>
            <div className="text-text-primary font-medium mb-4" style={{ fontSize: 14, fontFamily: 'var(--font-tight)' }}>
              Summer Campaign Go-live
            </div>
            <ConfidenceBar
              p50Label="14 Mar"
              p85Label="22 Mar"
              p95Label="28 Mar"
              targetPosition={0.88}
              p50Position={0.33}
              p85Position={0.66}
              height={10}
            />
          </div>

          {/* KPI mini card */}
          <div
            className="rounded-xl p-5 bg-surface self-end"
            style={{ width: 280, border: '1px solid #E8E6E1', boxShadow: '0 4px 12px rgba(23,22,20,0.06)', marginTop: -20 }}
          >
            <div className="text-text-tertiary uppercase mb-2" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>This cycle</div>
            <div className="flex items-end gap-2">
              <span style={{ fontSize: 32, fontWeight: 600, fontFamily: 'var(--font-mono)', color: '#171614' }}>89</span>
              <span className="text-on-track mb-1.5" style={{ fontSize: 12, fontWeight: 500 }}>tasks completed</span>
            </div>
          </div>

          {/* Proposal mini card */}
          <div
            className="rounded-xl p-4"
            style={{ background: '#EEEFFC', border: '1px solid #DCDDF8', boxShadow: '0 4px 12px rgba(23,22,20,0.06)', marginTop: -10 }}
          >
            <div className="flex items-center gap-2 mb-1">
              <SparkleIcon size={12} />
              <span className="text-text-tertiary uppercase" style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em' }}>From Slack · 2h ago</span>
            </div>
            <div className="text-text-primary font-medium" style={{ fontSize: 13 }}>Draft Q3 campaign kickoff agenda</div>
          </div>
        </div>

        <h3 style={{ fontSize: 20, fontWeight: 600, fontFamily: 'var(--font-tight)', color: '#171614', textAlign: 'center' }}>
          Forecasts, not guesses.
        </h3>
      </div>
    </div>
  );
}
