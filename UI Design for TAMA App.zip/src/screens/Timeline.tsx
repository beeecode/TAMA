import { Avatar, Button, PageHeader } from '../components/ui';
import { useState } from 'react';

const PROJECTS_DATA = [
  {
    name: 'Atlas CRM Revamp',
    color: '#22C55E',
    tasks: [
      { title: 'Data migration', start: 0, elapsedWidth: 3, totalWidth: 6, forecasted: true, assignee: { i: 'SP', c: '#F97316' } },
      { title: 'API integration', start: 2, elapsedWidth: 2, totalWidth: 5, forecasted: true, assignee: { i: 'TK', c: '#22C55E' } },
      { title: 'User testing', start: 5, elapsedWidth: 0, totalWidth: 4, forecasted: true, assignee: { i: 'CW', c: '#F2622E' } },
    ],
  },
  {
    name: 'Nimbus Dashboard',
    color: '#F97316',
    tasks: [
      { title: 'UI Design', start: 1, elapsedWidth: 3, totalWidth: 5, forecasted: true, assignee: { i: 'AM', c: '#EC4899' } },
      { title: 'Frontend build', start: 4, elapsedWidth: 0, totalWidth: 6, forecasted: true, assignee: { i: 'TK', c: '#22C55E' } },
    ],
  },
  {
    name: 'Vega Brand Refresh',
    color: '#8B5CF6',
    tasks: [
      { title: 'Campaign brief', start: 0, elapsedWidth: 2, totalWidth: 4, forecasted: false, assignee: { i: 'CW', c: '#F2622E' } },
      { title: 'Creative direction', start: 2, elapsedWidth: 1, totalWidth: 5, forecasted: true, assignee: { i: 'RK', c: '#8B5CF6' } },
      { title: 'Production', start: 6, elapsedWidth: 0, totalWidth: 5, forecasted: true, assignee: { i: 'AM', c: '#EC4899' } },
    ],
  },
  {
    name: 'Orion API Gateway',
    color: '#3B82F6',
    tasks: [
      { title: 'Auth spec', start: 1, elapsedWidth: 2, totalWidth: 4, forecasted: false, assignee: { i: 'TK', c: '#22C55E' } },
      { title: 'Rate limiting', start: 4, elapsedWidth: 0, totalWidth: 4, forecasted: true, assignee: { i: 'DP', c: '#22C55E' } },
    ],
  },
];

const DATES = ['Mar 10', 'Mar 11', 'Mar 12', 'Mar 13', 'Mar 14', 'Mar 15', 'Mar 16', 'Mar 17', 'Mar 18', 'Mar 19', 'Mar 20'];
const TODAY_COL = 4;

interface TooltipState {
  visible: boolean;
  x: number;
  y: number;
  task: string;
}

export default function Timeline() {
  const [activeTab, setActiveTab] = useState('Timeline');
  const [tooltip, setTooltip] = useState<TooltipState>({ visible: false, x: 0, y: 0, task: '' });
  const colWidth = 80;

  return (
    <div>
      <PageHeader
        breadcrumb="Workspace / Tasks"
        title="Tasks"
        tabs={['Overview', 'Lists', 'Board', 'Timeline', 'Files']}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      >
        <Button variant="secondary" size="sm">Status: All</Button>
      </PageHeader>

      {/* Controls */}
      <div className="flex items-center gap-4 mb-5">
        <div className="flex rounded-lg overflow-hidden" style={{ border: '1px solid #D6D3CC' }}>
          {['Week', 'Month', 'Quarter'].map((z, i) => (
            <button
              key={z}
              className="px-4 py-1.5 cursor-pointer transition-colors"
              style={{
                fontSize: 13,
                background: z === 'Week' ? '#171614' : '#FFFFFF',
                color: z === 'Week' ? '#FFFFFF' : '#6B6862',
                border: 'none',
                borderRight: i < 2 ? '1px solid #D6D3CC' : 'none',
              }}
            >
              {z}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div
            className="rounded-full flex-shrink-0"
            style={{ width: 10, height: 10, background: 'linear-gradient(to right, #DCDDF8, transparent)' }}
          />
          <span className="text-text-secondary" style={{ fontSize: 13 }}>Uncertainty bands on</span>
        </div>
        <div className="flex items-center gap-4" style={{ marginLeft: 'auto' }}>
          {[{ label: 'Completed', color: '#22C55E' }, { label: 'Forecasted', color: '#8B8FE8' }, { label: 'Milestone', color: '#171614' }].map(l => (
            <div key={l.label} className="flex items-center gap-1.5">
              <div className="rounded-full" style={{ width: 8, height: 8, background: l.color }} />
              <span className="text-text-tertiary" style={{ fontSize: 12 }}>{l.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline grid */}
      <div
        className="bg-surface rounded-xl overflow-hidden"
        style={{ border: '1px solid #E8E6E1', boxShadow: '0 1px 2px rgba(23,22,20,0.04)' }}
      >
        <div className="flex">
          {/* Left column */}
          <div style={{ width: 240, flexShrink: 0, borderRight: '1px solid #E8E6E1' }}>
            <div style={{ height: 48, borderBottom: '1px solid #E8E6E1', background: '#F5F4F1' }} />
            {PROJECTS_DATA.map(project => (
              <div key={project.name}>
                {/* Project row */}
                <div
                  className="flex items-center gap-2 px-4"
                  style={{ height: 40, borderBottom: '1px solid #E8E6E1', background: '#FAFAF8' }}
                >
                  <div className="rounded" style={{ width: 10, height: 10, background: project.color, borderRadius: 3 }} />
                  <span className="text-text-primary font-medium" style={{ fontSize: 12, fontFamily: 'var(--font-tight)' }}>{project.name}</span>
                </div>
                {/* Task rows */}
                {project.tasks.map((task) => (
                  <div
                    key={task.title}
                    className="flex items-center px-6"
                    style={{ height: 44, borderBottom: '1px solid #E8E6E1' }}
                  >
                    <span className="text-text-secondary truncate" style={{ fontSize: 12 }}>{task.title}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Right grid */}
          <div className="flex-1 overflow-x-auto">
            {/* Date headers */}
            <div className="flex" style={{ height: 48, background: '#F5F4F1', borderBottom: '1px solid #E8E6E1', minWidth: DATES.length * colWidth }}>
              {DATES.map((date, i) => (
                <div
                  key={date}
                  className="flex flex-col items-center justify-center"
                  style={{
                    width: colWidth,
                    flexShrink: 0,
                    borderRight: '1px solid #E8E6E1',
                    background: i === TODAY_COL ? '#F0EEEA' : 'transparent',
                  }}
                >
                  <span style={{ fontSize: 10, color: '#9B9790', fontFamily: 'var(--font-sans)' }}>
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i % 7]}
                  </span>
                  <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: i === TODAY_COL ? '#171614' : '#9B9790', fontWeight: i === TODAY_COL ? 600 : 400 }}>
                    {date.split(' ')[1]}
                  </span>
                </div>
              ))}
            </div>

            {/* Task bars */}
            {PROJECTS_DATA.map(project => (
              <div key={project.name} style={{ minWidth: DATES.length * colWidth }}>
                {/* Project spacer */}
                <div
                  className="relative"
                  style={{ height: 40, borderBottom: '1px solid #E8E6E1', background: '#FAFAF9' }}
                >
                  {/* Vertical gridlines */}
                  {DATES.map((_, i) => (
                    <div key={i} className="absolute top-0 h-full" style={{ left: i * colWidth, width: colWidth, borderRight: '1px solid #E8E6E1' }} />
                  ))}
                  {/* Today line */}
                  <div
                    className="absolute top-0 h-full z-10"
                    style={{ left: TODAY_COL * colWidth, width: 2, background: '#F2622E' }}
                  />
                </div>

                {/* Task rows */}
                {project.tasks.map((task, ti) => (
                  <div
                    key={task.title}
                    className="relative flex items-center"
                    style={{ height: 44, borderBottom: '1px solid #E8E6E1' }}
                  >
                    {/* Gridlines */}
                    {DATES.map((_, i) => (
                      <div key={i} className="absolute top-0 h-full" style={{ left: i * colWidth, width: colWidth, borderRight: '1px dashed #E8E6E1' }} />
                    ))}
                    {/* Today line */}
                    <div className="absolute top-0 h-full z-10" style={{ left: TODAY_COL * colWidth, width: 2, background: '#F2622E', opacity: 0.6 }} />

                    {/* Bar */}
                    {task.forecasted ? (
                      <>
                        {/* Elapsed portion */}
                        {task.elapsedWidth > 0 && (
                          <div
                            className="absolute rounded-l-lg flex items-center z-20"
                            style={{
                              left: task.start * colWidth + 4,
                              width: task.elapsedWidth * colWidth - 4,
                              height: 32,
                              background: project.color,
                            }}
                          />
                        )}
                        {/* Forecasted uncertainty cone */}
                        <div
                          className="absolute flex items-center justify-between px-2 z-20 overflow-hidden"
                          onMouseEnter={(e) => {
                            const rect = (e.target as Element).getBoundingClientRect();
                            setTooltip({ visible: true, x: rect.left, y: rect.top - 80, task: task.title });
                          }}
                          onMouseLeave={() => setTooltip({ ...tooltip, visible: false })}
                          style={{
                            left: (task.start + task.elapsedWidth) * colWidth + 4,
                            width: (task.totalWidth - task.elapsedWidth) * colWidth - 8,
                            height: 32,
                            background: 'linear-gradient(to right, #B9BCF0, rgba(220,221,248,0.2))',
                            border: '1px solid rgba(139,143,232,0.3)',
                            borderRadius: task.elapsedWidth > 0 ? '0 8px 8px 0' : 8,
                          }}
                        >
                          <span className="text-ai-strong truncate" style={{ fontSize: 10, fontFamily: 'var(--font-mono)' }}>
                            forecast
                          </span>
                          <Avatar initials={task.assignee.i} color={task.assignee.c} size={20} />
                        </div>
                      </>
                    ) : (
                      <div
                        className="absolute flex items-center justify-between px-2 rounded-lg z-20"
                        style={{
                          left: task.start * colWidth + 4,
                          width: task.totalWidth * colWidth - 8,
                          height: 32,
                          background: project.color,
                        }}
                      >
                        <span className="text-white truncate" style={{ fontSize: 10 }}>{task.title}</span>
                        <Avatar initials={task.assignee.i} color={task.assignee.c} size={20} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tooltip */}
      {tooltip.visible && (
        <div
          className="fixed z-50 rounded-lg p-3 pointer-events-none"
          style={{ top: tooltip.y, left: tooltip.x, background: '#171614', boxShadow: '0 4px 12px rgba(0,0,0,0.2)' }}
        >
          <div className="text-white font-medium mb-2" style={{ fontSize: 12 }}>{tooltip.task}</div>
          {[{ label: 'P50', date: '14 Mar' }, { label: 'P85', date: '19 Mar' }, { label: 'P95', date: '24 Mar' }].map(r => (
            <div key={r.label} style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: '#B9BCF0' }}>
              {r.label} · {r.date}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
